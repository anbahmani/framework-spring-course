# Sommaire des cours — Architecture et Spring

Supports destinés à des étudiants qui connaissent Java et découvrent Spring ainsi que les frameworks d’API. Chaque séance dure **3 heures** et comprend un cours projetable, une démonstration guidée de 25 minutes, un TP de 65 minutes et un quiz corrigé de huit questions.

Le parcours utilise **Java 25, Maven 3.9 et Spring Boot 3.5.16**. Chaque séance comprend une démonstration guidée de 25 minutes — partie du cours — avant son TP distinct de 65 minutes. Les diagrammes de séquence UML sont intégrés aux supports et fonctionnent hors ligne.

| Séance | Cours | Démo | Atelier associé | Notions abordées |
| --- | --- | --- | --- |
| 1 | [Découvrir Spring et lancer sa première application](cours/01-premiers-pas.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-01-premiers-pas) | [Atelier 01 — Première application](ateliers/01-demarrage/index.html) | Framework, Spring Boot, contrôleur et première route |
| 2 | [Comprendre HTTP et envoyer des données JSON](cours/02-http-json.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-02-http-json) | [Atelier 02 — HTTP et JSON](ateliers/02-http-json/index.html) | Requêtes, réponses, paramètres, objets Java et JSON |
| 3 | [Comprendre les objets gérés par Spring et séparer les rôles](cours/03-injection-couches.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-03-injection-couches) | [Atelier 03 — Injection et service](ateliers/03-injection/index.html) | Beans, injection par constructeur, contrôleur et service |
| 4 | [Créer une petite API de gestion d’utilisateurs](cours/04-api-crud.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-04-api-crud) | [Atelier 04 — Annuaire en mémoire](ateliers/04-crud/index.html) | Requêtes CRUD, corps JSON, validation et statuts HTTP |
| 5 | [Conserver les données avec Spring Data JPA](cours/05-persistance.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-05-persistance) | [Atelier 05 — Annuaire persistant](ateliers/05-persistance/index.html) | Entité, repository, base H2 et persistance |
| 6 | [Vérifier son application et découvrir les transactions](cours/06-tests-transactions.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-06-tests-transactions) | [Atelier 06 — Tests et transactions](ateliers/06-tests/index.html) | JUnit, assertions, MockMvc et rollback |
| 7 | [Appeler une API depuis un programme Spring](cours/07-client-http.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-07-client-http) | [Atelier 07 — Client HTTP](ateliers/07-client/index.html) | RestClient, contrat HTTP, JSON et erreurs de connexion |
| 8 | [Découvrir les messages asynchrones avec Spring JMS](cours/08-messages.html) | [Démo du cours](https://github.com/anbahmani/framework-spring-demos/tree/main/course-08-messages) | [Atelier 08 — Messages texte](ateliers/08-messages/index.html) | Producteur, broker, file et consommateur |

## Ressources

- [Dépôt GitHub séparé des huit démos](https://github.com/anbahmani/framework-spring-demos) · [Sommaire des démos sur le site](demos/index.html)
- [Préparer le poste et démarrer les ateliers](demarrage.html)
- [Glossaire Spring](guide-spring.html)
- [Guide pédagogique](guide-pedagogique.html)
- [Bilan de vérification](verification.html)
- [Télécharger les supports et projets des huit séances](telechargements/supports-spring-cours-complet-java25.zip)

La démonstration guidée est une partie à part entière du cours : elle introduit le concept sur un projet exécutable avant le TP. Le dépôt GitHub séparé regroupe les huit projets Maven ; les ateliers restent les espaces de modification des étudiants. Les diagrammes UML, la démonstration guidée, le TP et le quiz sont accessibles dans chaque cours ; le bouton **Diaporama** affiche une section à la fois.
